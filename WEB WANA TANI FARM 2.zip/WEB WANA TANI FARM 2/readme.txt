# 🌱 Website Kelompok Usaha Perhutanan Sosial Wana Tani

Repositori ini berisi website statis untuk **KUPS Wana Tani**, menampilkan profil kelompok, produk ternak sapi, produk pupuk organik, galeri, serta kontak dengan CTA WhatsApp.

---

## 📂 Struktur Folder
